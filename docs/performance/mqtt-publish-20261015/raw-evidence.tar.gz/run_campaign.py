"""Task-local serial campaign; run from the task checkout after freezing binaries."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path.cwd()
OUT = ROOT / 'target/performance/mqtt-publish-20261015'
BIN = OUT / 'bin'
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from event_load import last_json, process_cpu_seconds
from connection_memory import free_port, rss_kib


def execute(name, command, env=None):
    with (OUT / 'commands.jsonl').open('a') as log:
        log.write(json.dumps({'name': name, 'command': command, 'env': env or {}}) + '\n')
    with (OUT / f'{name}.json').open('w') as out, (OUT / f'{name}.stderr').open('w') as err:
        result = subprocess.run(command, stdout=out, stderr=err,
                                env={**os.environ, **(env or {})}, timeout=180)
    print(name, 'exit', result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(name)
    return json.loads((OUT / f'{name}.json').read_text())


def event(name, variant, options):
    command = ['python3', 'scripts/perf/event_load.py', '--server-bin', str(BIN / f'server-{variant}'),
               '--loadgen-bin', str(BIN / 'loadgen'), '--connections', '64', '--rate', '30000',
               '--duration', '15', '--warmup', '3', '--cooldown', '2', '--qos', '1',
               '--payload-bytes', '1024', '--sink-mode', 'none', '--server-workers', '10',
               '--audit-open-loop', '--no-lock-metrics', *options]
    d = execute(name, command)
    c = d['load']['stats']['counters']
    metrics = {s.split()[0]: float(s.split()[1]) for s in d['metrics'].splitlines() if s and not s.startswith('#')}
    assert d['load_exit'] == d['server_exit'] == 0, name
    assert c.get('connected') == c.get('disconnected') == 64, (name, c)
    assert not d['load']['stats']['error_samples'], (name, c)
    for counter in ['client_errors', 'ack_timeouts', 'panicked_tasks', 'forced_tasks', 'pending_at_disconnect']:
        assert c.get(counter, 0) == 0, (name, counter, c)
    assert metrics['netbaiot_events_accepted_total'] == metrics['netbaiot_sink_acks_total'] == c['published'], (name, c)
    assert metrics['netbaiot_sink_pending'] == 0, name
    print(name, 'published/accepted/sink_ack', c['published'], 'cpu_s', d['server_cpu_load_seconds'], flush=True)


def paired():
    # All binaries are already built; no compilation runs during this campaign.
    env = {**os.environ, 'NETBAIOT_SECOND_ROUND': '1'}
    for run in range(1, 6):
        for variant in ('ab' if run % 2 else 'ba'):
            with (OUT / f'trie-{run}-{variant}.log').open('w') as out:
                subprocess.run([str(BIN / f'trie-{variant}'), 'second_round_trie_matching',
                                '--ignored', '--nocapture', '--test-threads=1'],
                               env=env, stdout=out, stderr=subprocess.STDOUT, check=True)
    scenarios = [
        ('uplink', 5, ['--subscribe-uplink', '--duration', '10']),
        ('down', 5, ['--subscribe-down']),
        ('webhook', 3, ['--subscribe-down', '--sink-mode', 'webhook', '--rate', '1000', '--duration', '10']),
        ('locks', 3, ['--subscribe-down', '--lock-metrics', '--duration', '10']),
    ]
    for scenario, rounds, options in scenarios:
        for run in range(1, rounds + 1):
            for variant in ('ab' if run % 2 else 'ba'):
                event(f'{scenario}-{run}-{variant}', variant, options)


def extra():
    for scenario, options in [
        ('qos0', ['--qos', '0', '--payload-bytes', '128']),
        ('qos2', ['--qos', '2', '--rate', '10000']),
        ('tls5', ['--tls', '--mqtt-v5', '--mqtt-metadata', '--rate', '10000']),
        ('slow', ['--sink-mode', 'webhook', '--sink-delay-ms', '10', '--rate', '200']),
        ('outage', ['--sink-mode', 'webhook', '--sink-outage-seconds', '1', '--rate', '300']),
    ]:
        for variant in 'ab':
            event(f'{scenario}-{variant}', variant, ['--subscribe-down', '--duration', '10', *options])
    for count in (1000, 10000):
        for variant in 'ab':
            execute(f'memory-{count}-{variant}', ['python3', 'scripts/perf/connection_memory.py',
                    '--transport', 'mqtt', '--connections', str(count), '--hold-seconds', '8',
                    '--density', '--subscribe', '--ramp-per-second', '1000',
                    '--server', str(BIN / f'server-{variant}'), '--loadgen', str(BIN / 'loadgen')],
                    {'TOKIO_WORKER_THREADS': '10'})
    for variant in 'ab':
        execute(f'fairness-{variant}', ['python3', 'scripts/perf/mixed_load.py',
                '--scenario', 'route-fairness', '--duration', '15', '--warmup', '3', '--cooldown', '2',
                '--server-workers', '10', '--server-bin', str(BIN / f'server-{variant}'),
                '--loadgen-bin', str(BIN / 'loadgen')])


def mosquitto():
    broker = shutil.which('mosquitto') or '/usr/local/sbin/mosquitto'
    for scenario in ('down', 'uplink'):
        for run in range(1, 4):
            options = ['--subscribe-down'] if scenario == 'down' else ['--subscribe-uplink', '--duration', '10']
            if run % 2 == 0:
                event(f'refnet-{scenario}-{run}-b', 'b', options)
            port = free_port()
            with tempfile.TemporaryDirectory(prefix='netbaiot-reference-') as tmp:
                tmp = Path(tmp)
                conf = tmp / 'mosquitto.conf'
                conf.write_text(f'listener {port} 127.0.0.1\nallow_anonymous true\npersistence false\nlog_type error\n')
                cfg = {'transport': 'mqtt', 'address': f'127.0.0.1:{port}', 'connections': 64,
                       'tenant_width': 65, 'ramp_per_sec': 64, 'warmup_secs': 3, 'duration_secs': 15 if scenario=='down' else 10,
                       'cooldown_secs': 2, 'publish_rate': 30000, 'payload_bytes': 1024, 'qos': 1,
                       'subscribe': True, 'subscribe_down_only': scenario == 'down',
                       'subscribe_uplink': scenario == 'uplink', 'audit_open_loop': True,
                       'report_every_secs': 5}
                loadconf = tmp / 'load.json'
                loadconf.write_text(json.dumps(cfg))
                name = f'mosquitto-{scenario}-{run}'
                with (OUT / f'{name}.broker.log').open('w') as log:
                    server = subprocess.Popen([broker, '-c', str(conf)], stdout=log, stderr=log)
                    load = None
                    try:
                        import socket
                        deadline = time.monotonic() + 5
                        while True:
                            try:
                                with socket.create_connection(('127.0.0.1', port), timeout=.1):
                                    break
                            except OSError:
                                assert server.poll() is None and time.monotonic() < deadline
                                time.sleep(.02)
                        cpu = process_cpu_seconds(server.pid)
                        started = time.monotonic()
                        with (OUT / f'{name}.load.log').open('w') as out, (OUT / f'{name}.stderr').open('w') as err:
                            load = subprocess.Popen([str(BIN / 'loadgen'), str(loadconf)], stdout=out, stderr=err)
                            rss = []
                            while load.poll() is None:
                                if time.monotonic() - started > 90:
                                    raise TimeoutError(name)
                                rss.append(rss_kib(server.pid))
                                time.sleep(.2)
                        elapsed = time.monotonic() - started
                        cpu = process_cpu_seconds(server.pid) - cpu
                        final = last_json((OUT / f'{name}.load.log').read_text(), 'final')
                        result = {'config': cfg, 'load': final, 'load_exit': load.returncode,
                                  'server_cpu_load_seconds': cpu, 'server_cpu_load_wall_seconds': elapsed,
                                  'rss_peak_kib': max(rss), 'mosquitto_config': conf.read_text()}
                        (OUT / f'{name}.json').write_text(json.dumps(result, indent=2))
                        assert load.returncode == 0 and not final['stats']['error_samples'], name
                        c = final['stats']['counters']
                        assert c['connected'] == c['disconnected'] == 64
                        assert c['published'] == c['pubacks']
                        print(name, 'published/puback', c['published'], flush=True)
                    finally:
                        if load is not None and load.poll() is None:
                            load.kill()
                            load.wait(timeout=5)
                        if server.poll() is None:
                            server.terminate()
                            server.wait(timeout=5)
            if run % 2:
                event(f'refnet-{scenario}-{run}-b', 'b', options)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['paired', 'extra', 'mosquitto'])
    args = parser.parse_args()
    globals()[args.phase]()
