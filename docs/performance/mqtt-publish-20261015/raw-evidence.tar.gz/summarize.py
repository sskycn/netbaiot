import json
import re
import statistics as st
from pathlib import Path

OUT = Path('target/performance/mqtt-publish-20261015')


def metrics(text):
    return {line.split()[0]: float(line.split()[1]) for line in text.splitlines() if line and not line.startswith('#')}


def row(path):
    d = json.loads(path.read_text())
    c = d['load']['stats']['counters']
    lat = d['load']['stats']['latencies']
    m = metrics(d.get('metrics', ''))
    duration = d.get('duration_seconds', d.get('config', {}).get('duration_secs'))
    accepted = m.get('netbaiot_events_accepted_total')
    sink = m.get('netbaiot_sink_acks_total')
    puback = c.get('measurement_pubacks')
    r = {'name': path.stem, 'counters': c,
         'puback_per_second': puback / duration if puback is not None else None,
         'published_per_second': c.get('measurement_published', 0) / duration,
         'gateway_accepted_total': accepted, 'sink_ack_total': sink,
         'sink_ack_full_lifecycle_per_second': sink / d['load']['elapsed_s'] if sink is not None else None,
         'cpu_us_per_event_full_lifecycle': d['server_cpu_load_seconds'] * 1e6 / accepted if accepted else None,
         'cpu_us_per_publish_full_lifecycle': d['server_cpu_load_seconds'] * 1e6 / c['published'],
         'cpu_percent_full_lifecycle': d['server_cpu_load_seconds'] * 100 / d['server_cpu_load_wall_seconds'],
         'rss_peak_kib': max((s['rss_kib'] for s in d.get('samples', [])), default=d.get('rss_peak_kib')),
         'pending_final': m.get('netbaiot_sink_pending'),
         'server_exit': d.get('server_exit'), 'load_exit': d['load_exit'],
         'errors': d['load']['stats']['error_samples'],
         'rejections_drops_retries_timeouts': {k:v for k,v in m.items() if k.endswith('_total') and any(x in k for x in ['reject','drop','retr','timeout'])},
         'latencies': lat}
    for k in ['p50_ms','p95_ms','p99_ms']:
        r['puback_' + k] = lat.get('puback', {}).get(k)
    for h in ['broker_lock_wait_us','broker_lock_hold_us','event_bus_lock_wait_us','event_bus_lock_hold_us',
              'broker_site_route_wait_ns','broker_site_route_hold_ns',
              'event_bus_site_publish_wait_ns','event_bus_site_publish_hold_ns',
              'eventbus_queue_latency_us','event_accepted_to_sink_ack_us','sink_latency_us']:
        count = m.get(f'netbaiot_{h}_count', 0)
        r[h + '_mean'] = m.get(f'netbaiot_{h}_sum', 0) / count if count else None
    return r


result = {'network': {}, 'trie': {}}
for scenario in ['down','uplink','uplink-long','refnet-down','refnet-uplink','webhook','locks','qos0','qos2','tls5','slow','outage','mosquitto-down','mosquitto-uplink']:
    groups = ['a','b'] if not scenario.startswith('mosquitto') else ['reference']
    result['network'][scenario] = {}
    for v in groups:
        pattern = f'{scenario}-*-{v}.json' if v != 'reference' else f'{scenario}-*.json'
        paths = [p for p in sorted(OUT.glob(pattern)) if re.fullmatch(re.escape(scenario) + (r'-\d+-' + v if v != 'reference' else r'-\d+') + r'\.json', p.name)]
        if not paths and v != 'reference':
            paths = sorted(OUT.glob(f'{scenario}-{v}.json'))
        rows = [row(p) for p in paths if p.stat().st_size]
        medians, ranges = {}, {}
        if rows:
            for key in rows[0]:
                values = [r[key] for r in rows if isinstance(r[key], (float, int))]
                if values:
                    medians[key] = st.median(values)
                    ranges[key] = [min(values), max(values)]
        result['network'][scenario][v] = {'runs': rows, 'medians': medians, 'ranges': ranges}

for v in 'ab':
    rows = []
    for path in sorted(OUT.glob(f'trie-*-{v}.log')):
        for line in path.read_text().splitlines():
            if 'SECOND_ROUND,' not in line:
                continue
            a = line[line.index('SECOND_ROUND,'):].split(',')
            rows.append({'file': path.name, 'case': a[1], 'subscriptions': int(a[2]), 'inner_run':int(a[3]),
                         'batch_mean_ns':float(a[4]), 'batch_p50_ns':float(a[5]),
                         'allocations_plus_reallocations':float(a[9]), 'requested_bytes':float(a[10])})
    result['trie'][v] = rows
(OUT / 'summary.json').write_text(json.dumps(result, indent=2))
for scenario, groups in result['network'].items():
    for v, g in groups.items():
        if g['runs']:
            print(scenario, v, len(g['runs']), {k:round(x, 3) for k,x in g['medians'].items()
                  if k in ['puback_per_second','cpu_us_per_event_full_lifecycle','puback_p99_ms','rss_peak_kib','broker_site_route_wait_ns_mean','broker_site_route_hold_ns_mean']})
