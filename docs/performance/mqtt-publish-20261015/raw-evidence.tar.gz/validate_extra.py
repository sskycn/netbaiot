import json,os,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'target/performance/mqtt-publish-20261015/validation'
env={**os.environ,'NETBAIOT_TEST_SERVER':str(root/'target/performance/mqtt-publish-20261015/bin/server-b')}
checks=[
 ('tls-outage-soak',['cargo','test','--locked','-p','netbaiot-server','--test','server','engineering_tls_qos1_http_sixty_second_soak','--','--ignored','--nocapture']),
 ('mixed-reconnect-soak',['cargo','test','--locked','-p','netbaiot-transports','--test','multi_codec','mixed_codec_reconnect_and_control_soak','--','--ignored','--nocapture']),
 ('fuzz-seeds',['python3','fuzz/seed_corpus.py']),
 ('fuzz-mqtt-state',['cargo','+nightly','fuzz','run','mqtt_state','--','-max_total_time=30','-max_len=1024','-rss_limit_mb=2048','-timeout=5']),
 ('fuzz-mqtt-recovery',['cargo','+nightly','fuzz','run','mqtt_recovery','--','-max_total_time=30','-max_len=1048576','-rss_limit_mb=2048','-timeout=5'])
]
results=[]
for name,command in checks:
 start=time.monotonic(); e=env.copy()
 if name.startswith('fuzz-'):e.update(CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2')
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.run(command,env=e,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 results.append({'name':name,'command':command,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start})
 (out/'extra-results.json').write_text(json.dumps(results,indent=2))
 print(name,p.returncode,flush=True)
 if p.returncode: print((out/(name+'.log')).read_text()[-4000:],flush=True)
