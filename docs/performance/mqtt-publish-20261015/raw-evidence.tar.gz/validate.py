"""Run correctness checks serially, retaining exit codes and complete logs."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path.cwd()
out = root / 'target/performance/mqtt-publish-20261015/validation'
out.mkdir(exist_ok=True)
env = {**os.environ, 'NETBAIOT_TEST_SERVER': str(root / 'target/performance/mqtt-publish-20261015/bin/server-b')}
checks = [
    ('fmt', ['cargo','fmt','--all','--','--check']),
    ('clippy', ['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),
    ('workspace', ['cargo','test','--workspace','--all-features']),
    ('perf-tools', ['python3','-m','unittest','discover','-s','scripts/perf','-p','test_*.py']),
    ('raw-regressions', ['python3','tests/mqtt_protocol_regressions.py','--repo','.','--output',str(out/'raw-regressions.json')]),
    ('conformance-tools', ['python3','-m','unittest','discover','-s','tests/mqtt_conformance','-p','test_*.py','-v']),
    ('conformance-release-gate', ['python3','tests/mqtt_conformance/run.py','--release-gate','--no-build']),
    ('mqtt5-smoke', ['python3','tests/mqtt_conformance/v5_smoke.py']),
    ('mqtt5-mosquitto', ['python3','tests/mqtt_conformance/v5_mosquitto.py']),
    ('sdk-build', ['cargo','build','--locked','-p','netbaiot-device-sdk','--example','device_mqtt']),
    ('sdk-mosquitto', ['python3','tests/run_device_profile_mosquitto.py']),
    ('device-profile', ['python3','tests/measure_device_profile.py']),
    ('restart-soak', ['cargo','test','--locked','-p','netbaiot-server','--test','server','subprocess_graceful_restart_sixty_second_soak','--','--ignored','--nocapture']),
]
results = []
for name, command in checks:
    began = time.monotonic()
    with (out / f'{name}.log').open('w') as log:
        p = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
    result = {'name':name,'command':command,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-began}
    results.append(result)
    (out / 'results.json').write_text(json.dumps(results, indent=2))
    print(name, p.returncode, flush=True)
    if p.returncode:
        print((out / f'{name}.log').read_text()[-4000:], flush=True)
        raise SystemExit(p.returncode)
